@echo off
cd /d "%~dp0"
py server.py --lan
pause
