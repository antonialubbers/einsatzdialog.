#!/usr/bin/env python3
"""EINSATZDIALOG: lokaler Webserver + nur lokaler Ollama-Proxy.

Ohne --lan: nur 127.0.0.1 (eigener Computer).
Mit --lan: iPad-Zugang im Heim-WLAN, API durch zufälligen Freigabecode geschützt.
Keine zusätzlichen Python-Pakete nötig. Kein Ollama-Netzwerkport wird freigegeben.
"""
import json
import os
import secrets
import socket
import sys
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

PORT = int(os.environ.get('EINSATZDIALOG_PORT', '8765'))
LAN = '--lan' in sys.argv
PIN = secrets.token_hex(4) if LAN else ''
OLLAMA = 'http://127.0.0.1:11434'
HOME = Path(__file__).resolve().parent


def addresses():
    found = set()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(('192.0.2.1', 80))
            found.add(sock.getsockname()[0])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            found.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in found if not ip.startswith(('127.', '169.254.')))


def local_models():
    with urlopen(OLLAMA + '/api/tags', timeout=6) as result:
        payload = json.loads(result.read(5_000_000))
    # Cloud-Angebote sind absichtlich ausgeschlossen: ausschließlich lokale Modelle.
    return [m.get('name', '') for m in payload.get('models', [])
            if isinstance(m, dict) and isinstance(m.get('name'), str)
            and m['name'] and ':cloud' not in m['name'].lower()]


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(HOME), **kwargs)

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cache-Control', 'no-store' if urlsplit(self.path).path.startswith('/api/') else 'no-cache')
        super().end_headers()

    def json_reply(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def allow_api(self):
        if LAN and not secrets.compare_digest(self.headers.get('X-Einsatzdialog-PIN', ''), PIN):
            self.json_reply(401, {'error': 'Freigabecode fehlt oder ist falsch. Den Code zeigt der Computer beim Start an.'})
            return False
        origin = self.headers.get('Origin')
        if origin:
            expected = f"http://{self.headers.get('Host', '')}"
            if origin != expected:
                self.json_reply(403, {'error': 'Zugriff von einer anderen Webseite nicht erlaubt.'})
                return False
        return True

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/api/models':
            if not self.allow_api():
                return
            try:
                return self.json_reply(200, {'models': local_models()})
            except (URLError, OSError, ValueError, TimeoutError) as ex:
                return self.json_reply(503, {'error': 'Ollama nicht erreichbar: ' + str(ex)[:150]})
        # Keine Verzeichnisansicht, kein Python-Quellcode oder README im Browser bereitstellen.
        if path == '/':
            self.path = '/index.html'
        elif path not in ('/index.html', '/style.css', '/scenarios.js', '/app.js', '/pwa.js', '/sw.js', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png', '/icons/icon-180.png', '/icons/icon-64.png', '/icons/icon.svg', '/icon-192.png', '/icon-512.png', '/icon-180.png', '/icon-64.png', '/icon.svg'):
            self.send_error(404, 'Nicht gefunden')
            return
        if path == "/manifest.webmanifest":
            self.extensions_map[".webmanifest"] = "application/manifest+json"
        return super().do_GET()

    def do_POST(self):
        if urlsplit(self.path).path != '/api/chat':
            return self.json_reply(404, {'error': 'Unbekannter Endpunkt'})
        if not self.allow_api():
            return
        if self.headers.get('Content-Type', '').split(';')[0].strip().lower() != 'application/json':
            return self.json_reply(415, {'error': 'JSON erwartet'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 2 <= size <= 90_000:
                return self.json_reply(413, {'error': 'Anfrage zu groß'})
            data = json.loads(self.rfile.read(size))
            model = data.get('model')
            messages = data.get('messages')
            if not isinstance(model, str) or model not in local_models():
                return self.json_reply(400, {'error': 'Nur installierte lokale Modelle sind erlaubt. Bitte vorher ollama pull ausführen.'})
            if not isinstance(messages, list) or not (1 <= len(messages) <= 45):
                return self.json_reply(400, {'error': 'Ungültige Nachrichtenliste'})
            cleaned = []
            for item in messages:
                if (not isinstance(item, dict) or item.get('role') not in ('system', 'user', 'assistant')
                        or not isinstance(item.get('content'), str)):
                    return self.json_reply(400, {'error': 'Ungültige Nachricht'})
                cleaned.append({'role': item['role'], 'content': item['content'][:6500]})
            req = Request(
                OLLAMA + '/api/chat',
                data=json.dumps({'model': model, 'messages': cleaned,
                                 'stream': False,
                                 'options': {'temperature': 0.7, 'num_predict': 350}}).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
            )
            with urlopen(req, timeout=115) as answer:
                output = json.loads(answer.read(3_000_000))
            content = str(output.get('message', {}).get('content', ''))[:5500]
            return self.json_reply(200, {'message': {'content': content}})
        except HTTPError as ex:
            return self.json_reply(502, {'error': f'Ollama meldet HTTP {ex.code}. Ist das Modell installiert?'})
        except (OSError, URLError, TimeoutError, ValueError, KeyError, TypeError) as ex:
            return self.json_reply(503, {'error': 'Lokale KI nicht verfügbar: ' + str(ex)[:160]})


if __name__ == '__main__':
    bind = '0.0.0.0' if LAN else '127.0.0.1'
    print('\n' + '=' * 60)
    print('EINSATZDIALOG: VERSION 0.3 - PWA + iPAD + OLLAMA')
    print('Computer: http://127.0.0.1:' + str(PORT))
    if LAN:
        print('\nIm iPad Safari öffnen (selbes WLAN):')
        ips = addresses()
        if ips:
            for ip in ips:
                print(f'  http://{ip}:{PORT}')
        else:
            print('  http://<IPv4-Adresse-deines-Computers>:' + str(PORT))
        print('\nFreigabecode für KI-Einstellungen: ' + PIN)
        print('Nur im vertrauenswürdigen Heim-WLAN verwenden.')
        print('Keine Router-Portfreigabe für 8765 oder 11434 einrichten!')
    print('\nBeenden: Strg+C')
    print('=' * 60 + '\n')
    try:
        ThreadingHTTPServer((bind, PORT), Handler).serve_forever()
    except OSError as ex:
        sys.exit(f'Server konnte nicht starten: {ex}')
