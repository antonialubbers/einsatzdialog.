# EINSATZDIALOG 0.3 · iPad-Web-App

## Was du erhältst

- Eine installierbare PWA (Homescreen-Icon, Vollbild, eigener App-Name).
- Für die **regelbasierte** Simulation: Fachwissen vor dem Fall, Organisationsauswahl (Feuerwehr, Rettungsdienst, THW, Polizei), fünf Schwierigkeitsstufen, verdeckte Fälle, Nachbesprechung, Folgetraining, Speicherung des Lernfortschritts auf dem Gerät.
- Offline-Cache über Service Worker: **erst nach einem erfolgreichen ersten Aufruf über HTTPS** und vollständigem Laden der App. Externe verlinkte Fachquellen benötigen weiterhin Internet.
- Optional einen lokalen Python-Server als Zugang zur eigenen Ollama-Installation im Heim-WLAN.

## Wichtig: Noch kein veröffentlichter Link

Die Dateien sind fertig, aber die App ist noch nicht unter einer öffentlichen HTTPS-Adresse gehostet. Eine ZIP-Datei allein lässt sich auf einem iPad nicht als PWA installieren. Für die Installation brauchst du **einmalig eine HTTPS-Webadresse**. Kostenlose statische Hosting-Angebote sind möglich; die genauen Nutzungsgrenzen können sich ändern.

## Kostenlose Veröffentlichung auf GitHub Pages

1. Kostenloses GitHub-Konto anlegen oder anmelden: https://github.com
2. Neues **öffentliches** Repository erstellen, z. B. `einsatzdialog`. Keine echten Patientendaten, Geheimnisse oder API-Schlüssel hochladen.
3. Die Dateien aus dem Ordner `einsatzdialog_webapp_upload` hochladen, **dessen Inhalt direkt ins Repository-Hauptverzeichnis**. `index.html` muss im Hauptverzeichnis liegen. Die ZIP-Datei selbst nicht als einzelne Datei hochladen. Die Dateien liegen bewusst flach in einem Ordner, sodass die Auswahl vom iPad etwas einfacher ist.
4. Im Repository `Settings` → `Pages` → `Build and deployment` → `Deploy from a branch` → `main` und `/(root)` wählen → `Save`.
5. Warten, bis GitHub Pages den HTTPS-Link anzeigt. Darin liegt dann die Web-App. Das erste Laden braucht Internet.
6. Auf dem iPad den Link in **Safari** öffnen → Teilen → „Zum Home-Bildschirm“ (ggf. „Mehr anzeigen“) → „Als Web-App öffnen“ aktivieren → „Hinzufügen“.
7. Die App vom Homescreen öffnen. Der regelbasierte Modus funktioniert nach erfolgreichem ersten Laden auch offline, soweit die Cache-Daten nicht gelöscht wurden.

Offizielle GitHub-Anleitung: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
Apple-Anleitung: https://support.apple.com/guide/ipad/open-as-web-app-ipad8f1f7a29/27/ipados/27

**Hinweise zum iPad-Upload:** Das Hochladen mehrerer Dateien über Safari/GitHub kann je nach Browseransicht umständlich sein. Für die Erstveröffentlichung ist ein Computer oft einfacher. Wenn du ausschließlich ein iPad hast, kannst du die ZIP-Datei in „Dateien“ entpacken, die Web-App-Dateien auswählen und im Browser hochladen, sofern der GitHub-Dialog Mehrfachauswahl ermöglicht. Alternativ hilft eine Person einmalig beim Upload.

## Alternative: Netlify Drop auf einem Computer

- https://app.netlify.com/drop besuchen und den entpackten Ordner `einsatzdialog_webapp_upload` mit den Dateien hineinziehen.
- Danach erhältst du eine HTTPS-Adresse, die du auf deinem iPad öffnen und wie oben installieren kannst.
- Netlify-Tarife haben Nutzungsbedingungen und Limits; vor einer späteren öffentlichen Bereitstellung prüfen.

Offizielle Anleitung: https://docs.netlify.com/manage/projects/add-new-project/

## Ollama: weiterhin kostenlos lokal auf dem Computer

Der auf GitHub Pages / Netlify veröffentlichte **HTTPS-App-Modus** hat absichtlich *keine* direkte KI-Anbindung zu einem lokalen HTTP-Ollama-Server. Ein HTTPS-Browser darf nicht einfach eine unverschlüsselte Heimnetz-API ansprechen. **Eine kostenfreie Offline-App mit KI direkt auf dem iPad ist hier nicht enthalten.**

Für freiere KI-Gespräche auf dem iPad bei laufendem Computer:

1. Ollama auf Windows/Mac/Linux installieren: https://ollama.com/download
2. Im Computerterminal Modell laden: `ollama pull llama3.2:3b`.
3. Python 3 auf dem Computer verfügbar machen.
4. `server.py` zusammen mit `index.html`, `app.js`, `scenarios.js`, `style.css`, `pwa.js`, `sw.js` und den übrigen Dateien auf dem Computer im selben Ordner lassen.
5. Terminal dort öffnen, `python3 server.py --lan` (Mac/Linux) bzw. `py server.py --lan` (Windows) starten.
6. iPad ins gleiche, vertrauenswürdige WLAN: Die vom Computer angezeigte lokale Adresse in Safari öffnen (z. B. `http://192.168...:8765`).
7. „KI-Modus“ öffnen, den 8-stelligen Code aus dem Terminal eingeben, Verbindung prüfen und lokal installiertes Modell wählen.

**Wichtig:** Das ist ein alternativer **WLAN-Browsermodus**, keine Verbindung aus der installierten HTTPS-App heraus. Weil lokales HTTP unverschlüsselt ist, nur im eigenen vertrauenswürdigen Netz nutzen. Keine Router-Portfreigaben einrichten. Keine personenbezogenen Einsatz- oder Patientendaten eingeben. Vor der Nutzung von KI-Simulationen müssen Inhalte fachlich überprüft werden.

## Tests und Grenzen

- JavaScript-Syntax, HTML-UI-Funktionen und verschiedene Bildschirmgrößen wurden überprüft; echtes Safari-iPad-Verhalten und die GitHub-Pages-Veröffentlichung konnten hier nicht auf einem physischen iPad getestet werden.
- Das Offline-Feedback erkennt Schlüsselwörter und ist **keine objektive Kompetenzbewertung**. Die simulierten Reaktionen sind begrenzt und keine realweltliche PSNV- oder Rechtsberatung.
- Fortschritt wird im jeweiligen Browser bzw. in der Web-App lokal gespeichert; Löschen von Web-App-Daten kann den Verlauf entfernen.
- App-Inhalte liegen im statischen Web-Paket und sind keine offiziellen oder freigegebenen Dienstanweisungen.
